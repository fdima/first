window.onload = function () {
	$(".content2").css({'display': 'none'});
	$(".div-ticket-itog").css({'display': 'none'});
	$(".itog").css({'display': 'none'});
	$(".btn-success").attr({'disabled': 'disabled'});

	$(".row-choice").on('click',function(event){ 
		//console.log(event); innerText
		$(".row-choice").removeClass("row-choice-checed");
		$("#"+event.currentTarget.id).toggleClass("row-choice-checed");
		s = event.currentTarget.innerText;
		s = s.replace("бесплатно","");
		$(".header-div").html (s);
		$(".content1").css({'display': 'none'});
		$(".content2").css({'display': ''});
	});

	$(".data-choice").on('click', function(event) {
		$(".content2").css({'display': 'none'});
		$(".content1").css({'display': ''});
		$(".header-div").html ("Выберите дату и время");
	});

	$(".b-dec").on('click', function(event) {
		if (event.currentTarget.parentElement.children[1].value > 0) { 
			--event.currentTarget.parentElement.children[1].value;
		}
		printitog();
	});

	$(".b-inc").on('click', function(event) {
		if (event.currentTarget.parentElement.children[1].value < 10) { 
			++event.currentTarget.parentElement.children[1].value;
		}	
		printitog();
	});

	$("#ch-readed").on('click', function(event) {
		//console.log($( "#ch-readed:checked").val());
		if ($( "#ch-readed:checked").val() == 'on') {
			$(".btn-success").removeAttr("disabled");
		} else {
			$(".btn-success").attr({'disabled': 'disabled'});
		}
		//тут сделать валидацию полей!
	});

	$(".btn-success").on('click', function(event) {
		// собрать все данные для отправки
		//$(".header-div").text() // название с кнопки i-email i-name i-phone ch-anons ch-readed if ($( "#ch-readed:checked").val() == 'on') 
		var items = $(".item"); //ticket-name ticket-price
		var tickets_name = $(".ticket-name"); //ticket-name ticket-price
		var tickets_price = $(".ticket-price"); //ticket-name ticket-price
		var header = $(".header-div").text();
		var chanons  = $( "#ch-anons:checked").val();
		var chreaded = $( "#ch-readed:checked").val();
		var mail     = $( "#i-email").val();
		var fio      = $( "#i-name").val();
		var phone    = $( "#i-phone").val();
		console.log(items);
		console.log(tickets_name);
		console.log(tickets_price);
		console.log(header);
		console.log(chanons);
		console.log(chreaded);
		console.log(mail);
		console.log(fio);
		console.log(phone);
		alert(9);
	});	
}

function printitog() {
	//ticket-itog
	//var $y = $("input");
	var $y = $(".item"); //ticket-name ticket-price
	var count = 0;
	var sum =0;
	$y.each(function(index) {
		//console.log($(this).val());
		count = count + Number($(this).val()); 
		sum = sum + Number($(this).val()) * Number($(this).attr('price'));
	});
	//console.log(count);
	$(".ticket-itog").html("Вы выбрали "+count+" "+skl(count)+" на сумму "+sum+" руб.");
	//console.log(skl(count));
	if (count > 0) {
		$(".div-ticket-itog").css({'display': ''});
		$(".itog").css({'display': ''});
	} else {
		$(".div-ticket-itog").css({'display': 'none'});
		$(".itog").css({'display': 'none'});
	}
}

function skl(i) {
	//console.log(i);
	var list1 = [1,21];
	var list2 = [2,3,4,22,23,24];
	var list3 = [5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,25,26,27,28,29,30];
	if (i == 5) {
		return "билетов";
	}
	if (i in list1) {
		return "билет";
	}
	if (i in list2) {
		return "билета";
	}
	if (i in list3) {
		return "билетов";
	}
}