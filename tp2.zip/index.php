<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<link rel="stylesheet" type="text/css" href="./css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="./css/tp.css">
	<script src="./js/jquery.js" type="text/javascript"></script>
	<script src="./js/bootstrap.js" type="text/javascript"></script>
	<title></title>
	<link rel="shortcut icon" type="image/ico" href="./favicon.ico">
</head>
<body>
	<div class="page">
		<div class="content content1">
			<div class="header-div">
				Выберите дату и время
			</div>
			<div class="page-choice">
				<div class="row-choice" id="ch1">
					<div class="row-choice-date">18 июля (среда), 21:00</div>
					<div class="row-choice-dop"></div>
					<div class="row-choice-price">бесплатно</div>
				</div>
				<div class="row-choice" id="ch2">
					<div class="row-choice-date">18 июля (среда), 22:00</div>
					<div class="row-choice-dop"></div>
					<div class="row-choice-price">бесплатно</div>
				</div>		
				<div class="row-choice" id="ch3">
					<div class="row-choice-date">18 июля (среда), 23:00</div>
					<div class="row-choice-dop"></div>
					<div class="row-choice-price">бесплатно</div>
				</div>	
				<div class="row-choice" id="ch4">
					<div class="row-choice-date">18 июля (среда), 20:00</div>
					<div class="row-choice-dop"></div>
					<div class="row-choice-price">бесплатно</div>
				</div>
				<?
				
				?>
			</div>
		</div>
		<div class="content content2">
			<div class="header-div">
				конкретная дата
			</div>
			<div class="header-div-sub1">
				Выберите тип билетов:
			</div>
			<div class="header-div-sub2">
				<a href="#" class="data-choice">Выбрать новую дату</a>
			</div>
			<div class="page-choice">
				<div class="type-ticket">
					<div class="ticket-name">Бадминтон (оплата на месте от 1100 до 1300 рублей в зависимости от количества участников)</div>
					<div class="ticket-price">бесплатно</div>
					<div class="ticket-kol"><button class="b-dec">-</button><input value ="0" price="0" class="item"></input><button class="b-inc">+</button></div>
				</div>
				<div class="type-ticket">
					<div class="ticket-name">Абонемент (10 занятий, 1 занятие в подарок)</div>
					<div class="ticket-price">9900 руб.</div>
					<div class="ticket-kol"><button class="b-dec">-</button><input value ="0" price="9900" class="item"></input><button class="b-inc">+</button></div>
				</div>							
				<div class="type-ticket div-ticket-itog">
					<div class="ticket-itog"></div> <!--итого по счету -->
				</div>											
			</div>
			<div class="itog"> <!-- демоданные + расчет -->
				<form role="form">
				  <div class="form-group">
				    <label for="i-email">Email</label>
				    <input type="email" class="form-control" id="i-email" placeholder="Введите Ваш email">
				  </div>
				  <div class="form-group">
				    <label for="i-name">Имя</label>
				    <input type="text" class="form-control" id="i-name" placeholder="Введите Ваше имя">
				  </div>
				  <div class="form-group">
				    <label for="i-phone">Номер телефона</label>
				    <input type="text" class="form-control" id="i-phone" placeholder="Введите Ваш номер для связи">
				  </div>
				  <div class="checkbox">
				    <label>
				    <input type="checkbox" id="ch-anons"><span>Я хочу получать анонсы событий этого организатора по электронной почте</span>
				    </label>
				  </div>
				  <div class="checkbox">
				    <label>
				    <input type="checkbox" id="ch-readed"><span>Я подтверждаю свое согласие с условиями <a href="#">Пользовательского соглашения</a> и <a href="#">Договором оказания услуг по организации мероприятия и политикой возвратов</a></span>
				    </label>
				  </div>				  
				  <button type="button" class="btn-lg btn-success">Купить билет</button>
				</form>
			</div>
		</div>	
	</div>
	<script src="./js/tp.js" type="text/javascript"></script>
</body>
</html>