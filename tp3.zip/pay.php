<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title></title>
</head>
<body>
<form method="POST" action="https://money.yandex.ru/quickpay/confirm.xml">    
  <input type="hidden" name="receiver" value="41001741478922">    
  <input type="hidden" name="formcomment" value="sportme.network">    
  <input type="hidden" name="short-dest" value="Тут правильно указать данные о ивенте">    
  <input type="hidden" name="label" value="$order_id">   
  <input type="hidden" name="quickpay-form" value="donate">    
  <input type="hidden" name="targets" value="транзакция {order_id}">    
  <input type="hidden" name="sum" value="100.00" data-type="number">    
  <input type="hidden" name="comment" value="Тут тоже данные по ивенту - конкретно, что куплено и т.п.">   
  <input type="hidden" name="need-fio" value="false">    
  <input type="hidden" name="need-email" value="true">    
  <input type="hidden" name="need-phone" value="false">    
  <input type="hidden" name="need-address" value="false">    
  <input type="hidden" name="paymentType" value="AC"> 
  <input type="submit" value="Перевести">
</form>
</body>
</html>